<!DOCTYPE html>
<html>
    <body>
        <h1>
            "困困困，再睡会儿"
        </h1>
        <button onclick="window.location.href='wakeup.php'" type="button" id="add">"点击睡个回笼觉"</button>
    </body>
</html>
<?php
// $b=array('a');
// $a=hash_hmac('a',$b,'aaa');
// var_dump($a);
mt_srand(1);
echo(mt_rand());
echo("<br\>");
echo(mt_rand());
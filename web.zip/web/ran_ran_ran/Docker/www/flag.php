<?php
$flag="flag{shu_shu_chi_qin9_c4l}";
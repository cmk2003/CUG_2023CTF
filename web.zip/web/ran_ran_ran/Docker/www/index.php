<!DOCTYPE html>
<html>
    <h1>这里真的有flag嘛</h1>
    <h4>猫猫会不会帮你什么呢</h4>
    <img src="3.jpg" alt="">

</html>
<!--去问猫猫嘛，不要每次都是F12丝滑小连招~-->
<!--不一定依靠猫猫哟，你自己也可以成功-->

<?php
include "ran.php";
include "flag.php";
error_reporting(0);
$miao=randomkeys();
if(empty($_GET['mi'])||empty($_POST['laoshu'])){
    die("emmmmmm,you did nothing!");
}
if(isset($_GET['misiga'])){
    $miao=hash_hmac('sha256',$_GET['misiga'],$miao);
}else die("nonono~~~");
$musiga=hash_hmac('sha256',$_POST['laoshu'],$miao);
if($musiga!=$_GET['mi']){
    die("think harder!");
}else{
    echo("ya~~~~~");
    if($_POST['laoshu']=='system.out.println'){
        echo $flag;
    }
}


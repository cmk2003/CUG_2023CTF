#!/bin/bash

echo $FLAG >> /flag

rm -f /flag.sh
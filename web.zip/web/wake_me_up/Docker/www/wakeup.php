<?php
class flag{
    public $username;
    public function __wakeup(){
        $this->username = "guest";
    }
    public function __destruct(){

    }
}
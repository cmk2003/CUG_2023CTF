<?php
$flag = "flag{Really_do_not_want_to_get_up}";